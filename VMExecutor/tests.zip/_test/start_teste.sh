#Teste Tema 2 SO
bash test1.sh
bash test2.sh
bash test3.sh
bash test4.sh
bash test5.sh
bash test6.sh
bash test7.sh
bash test8.sh
