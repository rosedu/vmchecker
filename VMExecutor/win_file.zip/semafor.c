#include <windows.h>
#include <stdio.h>
#include "semafor.h"


HANDLE CreateSem (LPCTSTR key, int val, int maxVal)		// create and initialize a semaphore with a given key, initial value and a max value
{
return  CreateSemaphore( 
                 NULL,           // default security attributes
                 val,  // initial count
                 maxVal,  // maximum count
                 key);          // unnamed semaphore
}


HANDLE OpenSem (LPCTSTR key)
{
return	 OpenSemaphore(
	     SEMAPHORE_ALL_ACCESS,
 	     FALSE,
 	     key);
}

void CloseSem (HANDLE hSem)
{
	CloseHandle(hSem);
}

DWORD AcquireSem (HANDLE hSem)
{
   DWORD dwWaitResult;
   BOOL ok=TRUE;
   //Incerc sa trec de semafor (incerc sa decrementez valoarea semaforului)
   while(ok)
   {
  
   dwWaitResult = WaitForSingleObject(
 	  	   hSem,   //HANDLE-ul asociat semaforului
   		   0L);          //nu astept deloc (time-out de 0)
 
   switch (dwWaitResult)
   {
 	case WAIT_OBJECT_0:
        ok=FALSE;  	
		break;
 
 	case WAIT_TIMEOUT:
 		//Semaforul este in starea nonsignaled, a avut loc un time-out
 		//nu pot crea alta fereastra
 		break;
 
 	case WAIT_FAILED:
 		//tratere eroare (eventual cu functiile GetLastError si FormatMessage)
        return -1; 
		break;
   }
   }
return 0;

}

DWORD ReleaseSem (HANDLE hSem)
{
	 return ReleaseSemaphore( 
                        hSem,  // handle to semaphore
                        1,            // increase count by one
                        NULL);        // not interested in previous count
                
                //    printf("ReleaseSemaphore error: %d\n", GetLastError());
                
}