#ifndef SIMPLE_IPC_COMMON_H
 #define SIMPLE_IPC_COMMON_H
 

#define KEY_MSG			"\\\\.\\mailslot\\MessageQueue1" 
#define KEY_SHM				"Global\\SharedMemory"
#define KEY_SEM			"Global\\Semaphore1" 

#endif

