#include <windows.h>
#include <stdio.h>
#include "common.h"
#include "semafor.h"
#include "memorie.h"
#include "coada.h"
#include <string.h>
#include <tchar.h>

/* 4 KB */
#define SHM_SIZE 0x1000
#define NR_ELEM 256   //cate elemente (structuri nod) incap in mem. partajata


char heap[NR_ELEM]; //alocator de memorie
int indice=1;

typedef struct nod {
int val;
int stg;
int dr;
struct nod* frate; //folosit la tiparirea arborelui pe nivele|| se putea folosi o coada pentru a nu mai ocupa memoria partajata
}nod;

nod* memorie_partajata;

int aloca()
{
  int i;
  for (i=indice;i<NR_ELEM;i++)
      if (heap[i]=='\0')
          {
             indice=i+1;
             heap[i]='1';
             return i; 
          }
return -1;
}

void elibereaza(int i)
{
   heap[i]='\0';
   if (indice>i) indice=i;

}

int insereazaNod(int val,int p)
{
    if (p==-1)
    {
      p=aloca();
      if (p!=-1)
      {
      nod* temp=memorie_partajata+p;
      temp->val=val;
      temp->stg=-1;
      temp->dr=-1;
      }
    }
    else
    {
     nod* temp=memorie_partajata+p;
     if (val<temp->val) temp->stg=insereazaNod(val,temp->stg);
     else temp->dr=insereazaNod(val,temp->dr);
    }
   return p;
}

int stergeNod(int val, int p)
{

if (p!=-1)
  {
    nod* temp=memorie_partajata+p;
    if (temp->val==val)
    {
        if (temp->stg==-1)
          {
            int aux=p;
            p=temp->dr;
            elibereaza(aux); 
          }
        else
        if (temp->dr==-1)
          {
            int aux=p;
            p=temp->stg;
            elibereaza(aux); 
          }
       else
         {
           int r=temp->dr;
           int temp2=r;
           
           while((memorie_partajata+r)->stg!=-1)
               {
                 temp2=r;
                 r=(memorie_partajata+r)->stg;
               }
            temp->val=(memorie_partajata+r)->val;
  
            if (temp->dr==r) temp->dr=(memorie_partajata+r)->dr;
            else (temp2+memorie_partajata)->stg=(memorie_partajata+r)->dr;
            
            elibereaza(r); 
    
         }
    }
    else if (val <temp->val) temp->stg= stergeNod(val,temp->stg);
           else   temp->dr=stergeNod(val,temp->dr);
  }
  return p;
}


int main ()      
{
  

   HANDLE hMapFile;  //handle pt. memorie partajata
   HANDLE hQueueFile;  //handle pt. coada mesaje
   HANDLE hSemFile;  //handle pt. semafor
   LPTSTR mesaj;
 
   /* creare memoria partajata*/
  
   memset(heap,'\0',256);
  
   hMapFile=CreateSharedMemory (KEY_SHM	,SHM_SIZE);
   if (hMapFile==INVALID_HANDLE_VALUE)
   {
	   printf("CreateSharedMemory error: %d\n", GetLastError());
	   goto error;  
   }
  
   /* atasare segment memorie partajata*/
   memorie_partajata=(nod*) AttachSharedMemory (hMapFile);
   if (memorie_partajata==NULL)
    {
	   printf("AttachSharedMemory error: %d\n", GetLastError());
	   goto cleanup_err;  
    }
   /* creare coada de mesaje*/
   hQueueFile=CreateMessageQueue (KEY_MSG);
   if (hQueueFile==INVALID_HANDLE_VALUE)
   {
       printf("CreateMessageQueue error: %d\n", GetLastError());
	   goto cleanup_err;  
   }
   

    /*creare semafor*/
    hSemFile=CreateSem (KEY_SEM,1,1);	
    if (hSemFile==INVALID_HANDLE_VALUE)
    {
       printf("CreateSem error: %d\n", GetLastError());
	   goto cleanup_err;  
    }


     memorie_partajata->dr=-1;

                   
      //daemon(0,0);
      while (1)
      {   
      mesaj=ReceiveMessageQueue(hQueueFile);

      if (mesaj!=NULL)
         {
         if (mesaj[0]=='a')
                   { 
                    if (AcquireSem (hSemFile)==-1)
				    {
                     printf("AcquireSem error: %d\n", GetLastError());
	                 goto cleanup_err;
				    }
					//printf ("%s\n",mesaj);    
                    memorie_partajata->dr=insereazaNod(atoi(mesaj+2),memorie_partajata->dr);
                    if (!ReleaseSem(hSemFile))
				    {
                     printf("AcquireSem error: %d\n", GetLastError());
	                 goto cleanup_err;
				    }
                   }
           else if (mesaj[0]=='r')
                  { 
                    if (AcquireSem (hSemFile)==-1)
				    {
                     printf("AcquireSem error: %d\n", GetLastError());
	                 goto cleanup_err;
				    }
                    //printf ("%s\n",mesaj);
					memorie_partajata->dr=stergeNod(atoi(mesaj+2),memorie_partajata->dr);  
                    if (!ReleaseSem(hSemFile))
				    {
                     printf("AcquireSem error: %d\n", GetLastError());
	                 goto cleanup_err;
				    }
                  }
           else if (mesaj[0]=='c') 
                  {
                  if (AcquireSem (hSemFile)==-1)
				    {
                     printf("AcquireSem error: %d\n", GetLastError());
	                 goto cleanup_err;
				    }
                   //printf ("%s\n",mesaj);
				   memset(heap,'\0',256); 
                   memorie_partajata->dr=-1;   
                  if (!ReleaseSem(hSemFile))
				    {
                     printf("AcquireSem error: %d\n", GetLastError());
	                 goto cleanup_err;
				    }
                  }
           else if (mesaj[0]=='e')
                  {
                  //printf ("%s\n",mesaj);
                  /* detasare segment memorie partajata */
 	              DetachSharedMemory (memorie_partajata);

	              /* inchidere segment memorie partajata */
                  CloseSharedMemory (hMapFile);
       
	              /* inchidere semafor */
                  CloseSem (hSemFile);

                  /* inchidere coada */
                  CloseMessageQueue (hQueueFile);
   
                  exit(0);
                  }
	       }
	    else 
	    { 
		    printf("ReceiveMessageQueue error: %d\n", GetLastError());
	        goto cleanup_err;  
	    }
             
       }


return 0;
cleanup_err:
        
       /* detasare segment memorie partajata */
 	   DetachSharedMemory (memorie_partajata);

	   /* inchidere segment memorie partajata */
       CloseSharedMemory (hMapFile);
       
	   /* inchidere semafor */
       CloseSem (hSemFile);

       /* inchidere coada */
       CloseMessageQueue (hQueueFile);
error:
 	return -1;

}


