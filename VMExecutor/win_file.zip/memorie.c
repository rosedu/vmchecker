#include <windows.h>
#include <stdio.h>
#include "memorie.h"

HANDLE CreateSharedMemory (LPCTSTR key, int size)
{

	return CreateFileMapping(
		         INVALID_HANDLE_VALUE,    // use paging file
                 NULL,                    // default security 
                 PAGE_READWRITE,          // read/write access
                 0,                       // max. object size 
                 size,                // buffer size  
                 key);             
}

HANDLE OpenSharedMemory (LPCTSTR key)
{
    return OpenFileMapping(FILE_MAP_ALL_ACCESS,	// acces read/write
 			FALSE,			
 			key);	// numele obiectului
}
void CloseSharedMemory (HANDLE hShMem)
{
       CloseHandle(hShMem);
}



void *AttachSharedMemory (HANDLE hShMem)
{
	return MapViewOfFile(hShMem,   // handle to map object
                        FILE_MAP_ALL_ACCESS, // read/write permission
                        0,                   
                        0,                   
                        0); 
}

void DetachSharedMemory (void *lpMapAddress)
{
	UnmapViewOfFile(lpMapAddress);
}

