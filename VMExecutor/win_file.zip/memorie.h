#ifndef _INCLUDE_SHAREDMEMORY_
  #define _INCLUDE_SHAREDMEMORY_


HANDLE CreateSharedMemory (LPCTSTR key, int size);
HANDLE OpenSharedMemory (LPCTSTR key);
void CloseSharedMemory (HANDLE hShMem);
void *AttachSharedMemory (HANDLE hShMem);
void DetachSharedMemory (void *mem);

#endif
