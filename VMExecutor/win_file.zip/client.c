#include <windows.h>
#include <stdio.h>
#include "common.h"
#include "semafor.h"
#include "memorie.h"
#include "coada.h"
#include <string.h>
#include <tchar.h>

/* 4 KB */
#define SHM_SIZE 0x1000
#define MES_SIZE 10

typedef struct nod {
int val;
int stg;
int dr;
struct nod* frate;
}nod;

nod* memorie_partajata;

void printArb(int p)
{

if (p==-1)
  printf ("*\n");
else
{ 

nod * temp=memorie_partajata+p;
nod* prim=temp;
nod* ultim;

temp->frate=NULL;

printf("%d\n",temp->val);


while (prim!=NULL)
{
prim=NULL;

   while(temp!=NULL)
     {
  
     if (temp->stg!=-1)
      {
          printf("%d ",(memorie_partajata+temp->stg)->val);
          if (prim==NULL)
              {
               prim=memorie_partajata+temp->stg;
               ultim=prim;
               ultim->frate=NULL;  
               }
          else
             {
              ultim->frate=memorie_partajata+temp->stg;
              ultim=memorie_partajata+temp->stg;
              ultim->frate=NULL;
              }
      }
     else printf ("* ");
     if (temp->dr!=-1)
      {
          printf("%d ",(memorie_partajata+temp->dr)->val);
          if (prim==NULL)
              {
               prim=memorie_partajata+temp->dr;
               ultim=prim;
               ultim->frate=NULL;  
              }
          else
             {
              ultim->frate=memorie_partajata+temp->dr;
              ultim=memorie_partajata+temp->dr;
              ultim->frate=NULL;
              }
      }
     else printf("* "); 
     temp=temp->frate; 
     }
printf("\n");
temp=prim;
}
}
}


int main (int argc, char* argv[])      
{

   HANDLE hMapFile;  //handle pt. memorie partajata
   HANDLE hQueueFile;  //handle pt. coada mesaje
   HANDLE hSemFile;  //handle pt. semafor
   LPTSTR mesaj;
   int i;

   mesaj = (LPTSTR) HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, MES_SIZE*sizeof(TCHAR));

  /* deschidere segment memorie partajata*/
  
   hMapFile=OpenSharedMemory (KEY_SHM);
   if (hMapFile==INVALID_HANDLE_VALUE)
   {
	   printf("OpenSharedMemory error: %d\n", GetLastError());
	   goto error;  
   }
  
   /* atasare segment memorie partajata*/
   memorie_partajata=(nod*) AttachSharedMemory (hMapFile);
   if (memorie_partajata==NULL)
    {
	   printf("AttachSharedMemory error: %d\n", GetLastError());
	   goto cleanup_err;  
    }

   /* deschidere coada de mesaje*/
   hQueueFile=OpenMessageQueue (KEY_MSG);
   if (hQueueFile==INVALID_HANDLE_VALUE)
   {
       printf("OpenMessageQueue error: %d\n", GetLastError());
	   goto cleanup_err;  
   }
    
    /*deschidere semafor*/
    hSemFile= OpenSem(KEY_SEM);	
    if (hSemFile==INVALID_HANDLE_VALUE)
    {
       printf("OpenSem error: %d\n", GetLastError());
	   goto cleanup_err;  
    }

    i=1;

    while(i<argc)
           {
            if (argv[i][0]=='a')
                  { 
                   sprintf_s(mesaj,MES_SIZE, "a %s",argv[i+1]);
                   if (!SendMessageQueue (hQueueFile,mesaj))
				   {
                     printf("SendMessageQueue error: %d\n", GetLastError());
	                 goto cleanup_err;
				   }
                   i=i+1;
                  }
            else if (argv[i][0]=='r')
                  { 
                   sprintf_s(mesaj, MES_SIZE,"r %s",argv[i+1]);
                   if (!SendMessageQueue (hQueueFile,mesaj))
				   {
                     printf("SendMessageQueue error: %d\n", GetLastError());
	                 goto cleanup_err;
				   }
                   i=i+1;
                  }
            else if (argv[i][0]=='s')
                  { 
                  Sleep(atoi(argv[i+1]));
                  i=i+1;
                  }
            else if (argv[i][0]=='c') 
                  {
                   sprintf_s(mesaj,MES_SIZE, "c");
                   if (!SendMessageQueue (hQueueFile,mesaj))
				   {
                     printf("SendMessageQueue error: %d\n", GetLastError());
	                 goto cleanup_err;
				   }
			       }
            else if (argv[i][0]=='p')
                  {
                  if (AcquireSem (hSemFile)==-1)
				  {
                     printf("AcquireSem error: %d\n", GetLastError());
	                 goto cleanup_err;
				  }
				  printArb(memorie_partajata->dr);
				  if (!ReleaseSem(hSemFile))
				  {
                     printf("AcquireSem error: %d\n", GetLastError());
	                 goto cleanup_err;
				  }
				   
                  }
            else if (argv[i][0]=='e')
                  {
                   sprintf_s(mesaj,MES_SIZE, "e");
                   if (!SendMessageQueue (hQueueFile,mesaj))
				   {
                     printf("SendMessageQueue error: %d\n", GetLastError());
	                 goto cleanup_err;
				   }
			      }
                  
            i=i+1;           
	}

       /* detasare segment memorie partajata */
 	   DetachSharedMemory (memorie_partajata);

	   /* inchidere segment memorie partajata */
       CloseSharedMemory (hMapFile);
       
	   /* inchidere semafor */
       CloseSem (hSemFile);

       /* inchidere coada */
       CloseMessageQueue (hQueueFile);
       
	   return 0;

cleanup_err:
       
	   /* detasare segment memorie partajata */
 	   DetachSharedMemory (memorie_partajata);

	   /* inchidere segment memorie partajata */
       CloseSharedMemory (hMapFile);
       
	   /* inchidere semafor */
       CloseSem (hSemFile);

       /* inchidere coada */
       CloseMessageQueue (hQueueFile); 
error:
 	return -1;

}
