#include <windows.h>
#include <stdio.h>
#include "coada.h"

HANDLE CreateMessageQueue (LPCTSTR key)
{
	return CreateMailslot(
		         key, 
				 0,
                 MAILSLOT_WAIT_FOREVER, 
                 (LPSECURITY_ATTRIBUTES) NULL);
}

HANDLE OpenMessageQueue(LPCTSTR key)
{
    return CreateFile(
		    key,
		    GENERIC_WRITE,
			FILE_SHARE_READ|FILE_SHARE_WRITE,
            (LPSECURITY_ATTRIBUTES) NULL,
            OPEN_EXISTING,
			FILE_ATTRIBUTE_NORMAL,
			(HANDLE) NULL);
}

void CloseMessageQueue (HANDLE hMsgQueue)
{
       CloseHandle(hMsgQueue);
}

BOOL SendMessageQueue(HANDLE hMsgQueue,LPTSTR mesaj)
{
	DWORD cbWritten;
	return WriteFile(hMsgQueue,   // handle to map object
                     mesaj, // read/write permission
                     (DWORD)(lstrlen(mesaj)+1)*sizeof(TCHAR),                   
                     &cbWritten,
					 (LPOVERLAPPED) NULL); 
}

LPTSTR ReceiveMessageQueue (HANDLE hMsgQueue)
{
	DWORD cbMessage=0;
	DWORD cMessage=0;
	DWORD cbRead=0;
    BOOL fResult=TRUE;
	LPTSTR lpszBuffer;

	while((fResult)&&(!cMessage))
	{
		fResult=GetMailslotInfo(
			       hMsgQueue,
				   (LPDWORD) NULL,  //fara dim. max mesaj
				   &cbMessage,      //dimensiune mesaj urmator
				   &cMessage,       //nr. de mesaje
                   (LPDWORD) NULL); //fara expirare
	}

	if (!fResult) return NULL;

    lpszBuffer= (LPTSTR) HeapAlloc(GetProcessHeap(),HEAP_ZERO_MEMORY,cbMessage*sizeof(TCHAR));

    if (lpszBuffer==NULL) return NULL;

    fResult= ReadFile(hMsgQueue,
		      lpszBuffer,
			  cbMessage,
			  &cbRead,
			  (LPOVERLAPPED) NULL);

	if (!fResult)
	{
		HeapFree(GetProcessHeap(),0,lpszBuffer);
		return NULL;
	}

	return lpszBuffer;
}

