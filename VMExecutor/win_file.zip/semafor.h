#ifndef _INCLUDE_SEMAPHORE_
#define _INCLUDE_SEMAPHORE_

HANDLE CreateSem (LPCTSTR key, int val, int maxVal);		// create and initialize a semaphore with a given key, initial value and a max value
void DestroySem (HANDLE hSem);
HANDLE OpenSem (LPCTSTR key);
void CloseSem (HANDLE hSem);
DWORD AcquireSem (HANDLE hSem);
DWORD ReleaseSem (HANDLE hSem);

#endif
