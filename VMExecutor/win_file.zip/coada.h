#ifndef _INCLUDE_MESSAGEQUEUE_
#define _INCLUDE_MESSAGEQUEUE_


HANDLE CreateMessageQueue (LPCTSTR key);
HANDLE OpenMessageQueue (LPCTSTR key);
void CloseMessageQueue (HANDLE hMsgQueue);
void DestroyMessageQueue (HANDLE hMsgQueue);
BOOL SendMessageQueue (HANDLE hMsgQueue, LPTSTR src);
LPTSTR ReceiveMessageQueue (HANDLE hMsgQueue);

#endif
