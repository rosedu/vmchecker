#Tema 2 SO - Test 8
#Se testeaza daca s-au folosit anumite functii
echo "Started test 8 ..."
objdump -x ../server.exe | grep Semaphore &&\
objdump -x ../client.exe | grep Semaphore &&\
objdump -x ../server.exe | grep CreateMailslot &&\
objdump -x ../server.exe | grep CreateFileMapping &&\
objdump -x ../client.exe | grep OpenFileMapping
if [ $? -eq 0 ]
	then echo "-- PASSED --"
	else echo "-- FAILED --"
fi
echo
