#ifndef SEMAFOR_H
 #define SEMAFOR_H


int create_sem(key_t semKey);
int open_sem(key_t semKey);
int increment_sem(int semId);
int decrement_sem(int semId);
int erase_sem(int semId);
 
#endif
