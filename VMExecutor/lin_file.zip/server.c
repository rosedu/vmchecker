#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/stat.h>
#include "common.h"
#include "semafor.h"
#include <string.h>
#include <unistd.h>
#include <sys/sem.h>

/* 4 KB */
#define SHM_SIZE 0x1000
#define NR_ELEM 256   //cate elemente (structuri nod) incap in mem. partajata


char heap[NR_ELEM]; //alocator de memorie
int indice=1;

typedef struct nod {
int val;
int stg;
int dr;
struct nod* frate; //folosit la tiparirea arborelui pe nivele|| se putea folosi o coada pentru a nu mai ocupa memoria partajata
}nod;

nod* memorie_partajata;

int aloca()
{
  int i;
  for (i=indice;i<NR_ELEM;i++)
      if (heap[i]=='\0')
          {
             indice=i+1;
             heap[i]='1';
             return i; 
          }
return -1;
}

void elibereaza(int i)
{
   heap[i]='\0';
   if (indice>i) indice=i;

}

int insereazaNod(int val,int p)
{
    if (p==-1)
    {
      p=aloca();
      if (p!=-1)
      {
      nod* temp=memorie_partajata+p;
      temp->val=val;
      temp->stg=-1;
      temp->dr=-1;
      }
    }
    else
    {
     nod* temp=memorie_partajata+p;
     if (val<temp->val) temp->stg=insereazaNod(val,temp->stg);
     else temp->dr=insereazaNod(val,temp->dr);
    }
   return p;
}

int stergeNod(int val, int p)
{

if (p!=-1)
  {
    nod* temp=memorie_partajata+p;
    if (temp->val==val)
    {
        if (temp->stg==-1)
          {
            int aux=p;
            p=temp->dr;
            elibereaza(aux); 
          }
        else
        if (temp->dr==-1)
          {
            int aux=p;
            p=temp->stg;
            elibereaza(aux); 
          }
       else
         {
           int r=temp->dr;
           int temp2=r;
           
           while((memorie_partajata+r)->stg!=-1)
               {
                 temp2=r;
                 r=(memorie_partajata+r)->stg;
               }
            temp->val=(memorie_partajata+r)->val;
  
            if (temp->dr==r) temp->dr=(memorie_partajata+r)->dr;
            else (temp2+memorie_partajata)->stg=(memorie_partajata+r)->dr;
            
            elibereaza(r); 
    
         }
    }
    else if (val <temp->val) temp->stg= stergeNod(val,temp->stg);
           else   temp->dr=stergeNod(val,temp->dr);
  }
  return p;
}


struct my_msgbuf
{
	long mtype;
	char mtext[10];
};

int main ()      
{
        memset(heap,'\0',256);
        int segment;

        /* cheie pentru memoria partajata*/
 	key_t shmKey;
 	CHECK(shmKey = ftok(FILE_PATH, SHM_ID), "ftok", error);
 
	/* alocare segment memorie partajată */
 
	CHECK(segment = shmget(shmKey, SHM_SIZE, IPC_CREAT|IPC_EXCL| 0664),"shmget",error); /* 0664 = rw-rw-r--*/
 
	/* atașare segment memorie partajată */
	memorie_partajata = (nod*) shmat(segment, 0 ,0);
	if (memorie_partajata == (nod *) -1)
	{
		perror("shmat");
		goto cleanup_err;
 	}

        int coada;
        int mes_size;
	struct my_msgbuf mesaj;

        /* cheie pentru coada de mesaje*/
 	key_t mesKey;
 	CHECK(mesKey = ftok(FILE_PATH, MES_ID), "ftok", error);
 
 	CHECK(coada = msgget(mesKey, IPC_CREAT | 0666), "msgget", error);
    
       /*cheie pentru semafor*/
        key_t semKey;
 	CHECK(semKey = ftok(FILE_PATH, SEM_ID), "ftok", error);
 
 	int semId;	
 	CHECK(semId = create_sem(semKey), "crearea semaforului", error);
       
        CHECK(increment_sem(semId), "incrementarea semaforului",cleanup_err);
         
 	memorie_partajata->dr=-1;  
                    
        daemon(0,0);
        while (1)
        {   
        CHECK(mes_size=msgrcv(coada, &mesaj, 10, TIP, 0),"msgrcv",error);
        if (mes_size>0)
           {
           if (mesaj.mtext[0]=='a')
                   { 
                    CHECK(decrement_sem(semId), "decrementarea semaforului", cleanup_err);
                    memorie_partajata->dr=insereazaNod(atoi(mesaj.mtext+2),memorie_partajata->dr);
                    CHECK(increment_sem(semId), "incrementarea semaforului", cleanup_err);
                   }
           else if (mesaj.mtext[0]=='r')
                  { 
                    CHECK(decrement_sem(semId), "decrementarea semaforului", cleanup_err);
                    memorie_partajata->dr=stergeNod(atoi(mesaj.mtext+2),memorie_partajata->dr);  
                    CHECK(increment_sem(semId), "incrementarea semaforului", cleanup_err);
                  }
           else if (mesaj.mtext[0]=='c') 
                  {
                   CHECK(decrement_sem(semId), "decrementarea semaforului", cleanup_err);
                   memset(heap,'\0',256); 
                   memorie_partajata->dr=-1;   
                   CHECK(increment_sem(semId), "incrementarea semaforului", cleanup_err);
                  }
           else if (mesaj.mtext[0]=='e')
                  {
                   
                   /* detașare segment memorie partajată */
                   CHECK(shmdt(memorie_partajata),"detasare memorie partajata", cleanup_err);
 	           
        	   /* dealocare segment memorie partajată */
                   CHECK(shmctl(segment, IPC_RMID, NULL),"dealocare segment memorie partajata", error);
 	          
                   /* inchidere semafor*/
                   CHECK(erase_sem(semId),"stergere semafor", error);

                   /* distrugere coada */
                   CHECK(msgctl(coada,IPC_RMID,NULL),"stergere coada",error);
   
                   exit(0);
                  }
             }       
             
         }


return 0;

cleanup_err:
        
        /* dealocare segment memorie partajata */
 	if (shmctl(segment, IPC_RMID, NULL) == -1)
 	{
 		perror("shmctl");
 	}

        /* inchidere semafor */
        if (semctl(semId, 0, IPC_RMID)==-1)
        {
                perror("semctl");
        }  

        /* distrugere coada */
        if (msgctl(coada,IPC_RMID,NULL)==-1)
        {
                perror("msgctl");
        }  

error:
 	return -1;

}


