#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <string.h>
#include "common.h" 
#include "semafor.h"
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <sys/sem.h>

/* 4 KB */
#define SHM_SIZE 0x1000

typedef struct nod {
int val;
int stg;
int dr;
struct nod* frate;
}nod;

nod* memorie_partajata;

void printArb(int p)
{

if (p==-1)
  printf ("*\n");
else
{ 

nod * temp=memorie_partajata+p;
nod* prim=temp;
temp->frate=NULL;
nod* ultim;

printf("%d\n",temp->val);


while (prim!=NULL)
{
prim=NULL;

   while(temp!=NULL)
     {
  
     if (temp->stg!=-1)
      {
          printf("%d ",(memorie_partajata+temp->stg)->val);
          if (prim==NULL)
              {
               prim=memorie_partajata+temp->stg;
               ultim=prim;
               ultim->frate=NULL;  
               }
          else
             {
              ultim->frate=memorie_partajata+temp->stg;
              ultim=memorie_partajata+temp->stg;
              ultim->frate=NULL;
              }
      }
     else printf ("* ");
     if (temp->dr!=-1)
      {
          printf("%d ",(memorie_partajata+temp->dr)->val);
          if (prim==NULL)
              {
               prim=memorie_partajata+temp->dr;
               ultim=prim;
               ultim->frate=NULL;  
              }
          else
             {
              ultim->frate=memorie_partajata+temp->dr;
              ultim=memorie_partajata+temp->dr;
              ultim->frate=NULL;
              }
      }
     else printf("* "); 
     temp=temp->frate; 
     }
printf("\n");
temp=prim;
}
}
}


struct my_msgbuf
{
	long mtype;
	char mtext[10];
};


int main (int argc, char* argv[])      
{

        int segment;
        int i;

	
        key_t shmKey;
 	CHECK(shmKey = ftok(FILE_PATH, SHM_ID), "ftok", error);
 
	//segment memorie partajată 
 	   
	CHECK(segment = shmget(shmKey, SHM_SIZE, 0664),"shmget",error); // 0664 = rw-rw-r--
 
 
	// atașare segment memorie partajată 
	memorie_partajata = (nod*) shmat(segment, 0 ,0);
	if (memorie_partajata == (nod *) -1)
	{
		perror("shmat");
	}
		
	// deschidere coada de mesaje creata de server 
        int coada;
        int mes_size;
	struct my_msgbuf mesaj;
        key_t mesKey;
 	CHECK(mesKey = ftok(FILE_PATH, MES_ID), "ftok", error);
 
 	CHECK(coada = msgget(mesKey, 0004), "msgget", error);

        //deschidere semafor
        key_t semKey;
 	CHECK(semKey = ftok(FILE_PATH, SEM_ID), "ftok", error);
 
 	int semId;
 	CHECK(semId = open_sem(semKey), "deschiderea semaforului", error);

        i=1;

        while(i<argc)
           {
            if (argv[i][0]=='a')
                  { 
                   sprintf(mesaj.mtext, "a %s",argv[i+1]);
                   mesaj.mtype = TIP;
                   CHECK(mes_size=msgsnd(coada, &mesaj, strlen(mesaj.mtext)+1, 0),"msgsnd",error);
                   i=i+1;
                  }
            else if (argv[i][0]=='r')
                  { 
                   sprintf(mesaj.mtext, "r %s",argv[i+1]);
                   mesaj.mtype = TIP;
                   CHECK(mes_size=msgsnd(coada, &mesaj, strlen(mesaj.mtext)+1, 0),"msgsnd",error);
                  
                   i=i+1;
                  }
            else if (argv[i][0]=='s')
                  { 
                   sleep(atoi(argv[i+1])/1000);
                   usleep(atoi(argv[i+1])%1000*1000);
                   i=i+1;
                  }
            else if (argv[i][0]=='c') 
                  {
                   sprintf(mesaj.mtext, "c");
                   mesaj.mtype = TIP;
                   CHECK(mes_size=msgsnd(coada, &mesaj, strlen(mesaj.mtext)+1, 0),"msgsnd",error);
                  }
            else if (argv[i][0]=='p')
                  {
                   CHECK(decrement_sem(semId), "decrementarea semaforului",error);
                   printArb(memorie_partajata->dr);
                   CHECK(increment_sem(semId), "incrementarea semaforului", error);
                  }
            else if (argv[i][0]=='e')
                  {
                   sprintf(mesaj.mtext, "e");
                   mesaj.mtype = TIP;
                   CHECK(mes_size=msgsnd(coada, &mesaj, strlen(mesaj.mtext)+1, 0),"msgsnd",error);
                  }
                  
            i=i+1;           
            
         
           } 

 	/* detașare segment memorie partajată */
        CHECK(shmdt(memorie_partajata),"detasare memorie partajata", error);
 	
        return 0;
 
error:
 	return -1;


return 0;
}
