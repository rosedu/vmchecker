#include <sys/types.h>
#include <sys/wait.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <string.h>
#include "semafor.h" 
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <sys/sem.h>

int create_sem(key_t semKey)
 {
 	//cream o multime cu un singur semafor
 	//apelul esueaza daca exista deja un semafor cu cheia din semKey
 	return semget(semKey, 1, IPC_CREAT| 0660);
 }

int open_sem(key_t semKey)
 {
 	//deschidem un semafor existent
 	return semget(semKey, 1, 0);
 }

int erase_sem(int semId)
 {
 	//cand comanda este IPC_RMID, al doilea parametru este ignorat
 	return semctl(semId, 0, IPC_RMID);
 }


int increment_sem(int semId)
 {
 	struct sembuf sop;
 	sop.sem_num = 0;
 	sop.sem_op = +1;
 	sop.sem_flg = 0;
 	return semop(semId, &sop, 1);
 }
 
 
 int decrement_sem(int semId)
 {
 	struct sembuf sop;
 	//ne referim la primul semafor din multime (cel cu numarul 0)
 	sop.sem_num = 0;
 	sop.sem_op = -1;
 	sop.sem_flg = 0;
 	return semop(semId, &sop, 1);
 }
