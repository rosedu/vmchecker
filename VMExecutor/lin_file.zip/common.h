#ifndef SIMPLE_IPC_COMMON_H
 #define SIMPLE_IPC_COMMON_H
 

 #define TIP 1
 //constantele de mai jos vor fi folosite pentru obtinerea
 //unei chei cu functia ftok
 //calea va fi calea catre acest fisier
 const char* FILE_PATH = "./common.h";
 //un intreg oarecare
 const int SHM_ID = 123;
 const int SEM_ID = 124;
 const int MES_ID = 125;
 
 //functie macro utila pentru simplificarea codului de tratare
 //a erorilor
 #define CHECK(call, call_description, err_label) \
 	if ((call) == -1) \
 	{\
                fprintf(stderr, "(%s linia %d) Eroare la ",__FILE__,__LINE__);\
 		perror(call_description);\
 		goto err_label;\
 	}
 



#endif

